
public class Training {

    float[] data;
    float[] expectedOutput;

    public Training(float[] data, float[] expectedOutput) {
        this.data = data;
        this.expectedOutput = expectedOutput;
    }

}